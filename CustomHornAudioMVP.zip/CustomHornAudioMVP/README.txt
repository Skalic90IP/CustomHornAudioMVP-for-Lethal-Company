!!!
---
IMPORTANT NOTE, 
THE MOD IS MADE BY AI, 
DON'T TELL ME THAT THE MOD IS MADE TERRIBLY. 
IF YOU NOTICE ERRORS IN THE GAME ETC. REPORT TO ME ON THE DISCORD CHANNEL, THANKS FOR UNDERSTANDING.

LINK TO THE DISCORD CHANNEL - There is no server yet, sorry.
THE LINK CAN ALSO BE FOUND ON THE SITE.
---
!!!
---
ВАЖНАЯ ПОМЕТКА, 
МОД СДЕЛАН ИССКУСТВЕННЫМ ИНТЕЛЕКТОМ, 
НЕ ГОВОРИТЕ МНЕ ЧТО МОД СДЕЛАН УЖАСНО. 
ЕСЛИ ЗАМЕТИТЕ ОШИБКИ В ИГРЕ И Т.Д. СООБЩИТЕ МНЕ НА ДИСКОРД КАНАЛЕ, СПАСИБО ЗА ПОНИМАНИЕ

ССЫЛКА НА КАНАЛ ДИСКОРД - пока что сервера нету, извините.
ССЫЛКУ МОЖНО НАЙТИ ТАК ЖЕ НА САЙТЕ.
---
# **Custom Horn Mod for Lethal Company**  
**Replace the Load Horn sound with your own audio files!**  

---

## **English Instructions**  

### **Features**  
- Add custom `.wav`, `.ogg`, or `.mp3` sounds for the Load Horn.  
- Switch sounds using **Left/Right Arrow** keys.  
- Displays the current sound name on-screen.  
- Configurable volume and UI visibility.  

### **Installation**  
1. **Install BepInEx**  
   - Download [BepInEx Pack for Lethal Company].

2. **Install the Mod**  
   - Download `CustomHornMod.zip` from Thunderstore.  
   - Place it in `BepInEx/plugins` or install via R2ModManager.  

3. **Add Custom Sounds**  
   - Create a folder: `BepInEx/config/CustomHornSounds`.  
   - Place your `.wav`, `.ogg`, or `.mp3` files inside.  

4. **Launch the Game**  
   - Press **Left/Right Arrow** to switch sounds.  
   - The current sound name will appear on-screen.  

### **Configuration**  
- Edit `BepInEx/config/com.yourname.customhorn.cfg` to adjust:  
  - `Volume` (0.1 to 1.0).  
  - `ShowUI` (true/false).  

---

## **Инструкция на русском**  

### **Возможности**  
- Замена звука гудка (Load Horn) на свои файлы (`.wav`, `.ogg`, `.mp3`).  
- Переключение звуков **стрелками ←/→**.  
- Отображение названия текущего звука на экране.  
- Настройка громкости и интерфейса.  

### **Установка**  
1. **Установите BepInEx и R2ModManager**  
   - Скачайте [BepInEx для Lethal Company](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack_Lethal_Company/).  
   - Установите через **R2ModManager** (рекомендуется).  

2. **Установка мода**  
   - Скачайте `CustomHornMod.zip` из Thunderstore.  
   - Поместите в `BepInEx/plugins` или установите через R2ModManager.  

3. **Добавление своих звуков**  
   - Создайте папку: `BepInEx/config/CustomHornSounds`.  
   - Добавьте файлы `.wav`, `.ogg` или `.mp3`.  

4. **Запуск игры**  
   - Нажимайте **←/→** для переключения звуков.  
   - Название текущего звука будет отображаться на экране.  

### **Настройки**  
- Файл конфигурации: `BepInEx/config/com.yourname.customhorn.cfg`:  
  - `Volume` (громкость, от 0.1 до 1.0).  
  - `ShowUI` (показывать интерфейс: true/false).  

--- 

**Enjoy your custom loud horn sounds!** 